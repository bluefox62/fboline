<?php
// This is an example of config.php
$servername = 'us-cdbr-azure-southcentral-f.cloudapp.net';
$username = 'b0e1277b8c5931';
$password = 'c6147ed4';
$dbname = 'fboline';
?>
